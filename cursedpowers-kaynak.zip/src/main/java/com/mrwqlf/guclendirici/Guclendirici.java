package com.mrwqlf.guclendirici;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * CursedPowers - MRWQLF sunucusu icin guclendirici eklentisi.
 *
 * Ozellikler:
 *  1) Koyluler artik "Anlik Iyilesme" satmaz, onun yerine "Anlik Hasar" satar.
 *  2) Can Iksiri (Kucuk/Orta/Buyuk/Mega) - CUSTOM item (potion degil), sag tikta
 *     ANINDA tuketilir (bekleme/icme animasyonu yok), sabit can verir, 12 sn cooldown.
 *  3) Parsomenler - 3 kategori x 4 tier (Kucuk/Orta/Buyuk/Mega):
 *       - Saldiri Parsomeni  -> ATTACK_DAMAGE
 *       - Defans Parsomeni   -> ARMOR
 *       - Can Parsomeni      -> MAX_HEALTH
 *     Kullanilinca 1 saat etki verir, sure dolmadan ayni kategoriden tekrar kullanilamaz.
 */
public final class Guclendirici extends JavaPlugin implements Listener {

    private NamespacedKey keyCanIksiri;   // "kucuk" | "orta" | "buyuk" | "mega"
    private NamespacedKey keyParsomen;    // "saldiri_<tier>" | "defans_<tier>" | "can_<tier>"

    private static final long SURE_TICKS = 20L * 60L * 60L; // 1 saat (parsomen etki suresi)
    private static final long CAN_IKSIRI_COOLDOWN_MS = 12_000L; // 12 saniye ozel cooldown

    private final Map<UUID, Long> canIksiriCooldown = new HashMap<>();

    @Override
    public void onEnable() {
        keyCanIksiri = new NamespacedKey(this, "can_iksiri_tier");
        keyParsomen = new NamespacedKey(this, "parsomen_tier");
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("CursedPowers eklentisi aktif edildi.");
    }

    // =========================================================
    // 1) KOYLU TICARETI: Anlik Iyilesme -> Anlik Hasar
    // =========================================================
    @EventHandler
    public void onVillagerTrade(VillagerAcquireTradeEvent event) {
        MerchantRecipe recipe = event.getRecipe();
        ItemStack result = recipe.getResult();
        if (!isInstantHealthPotion(result)) return;

        ItemStack replaced = result.clone();
        PotionMeta meta = (PotionMeta) replaced.getItemMeta();
        if (meta == null) return;

        PotionType hedefTip = donusturInstantDamage(meta.getBasePotionType());
        if (hedefTip == null) return;

        meta.setBasePotionType(hedefTip);
        replaced.setItemMeta(meta);

        MerchantRecipe yeniRecipe = new MerchantRecipe(
                replaced, recipe.getUses(), recipe.getMaxUses(),
                recipe.hasExperienceReward(), recipe.getVillagerExperience(), recipe.getPriceMultiplier()
        );
        yeniRecipe.setIngredients(recipe.getIngredients());
        event.setRecipe(yeniRecipe);
    }

    private boolean isInstantHealthPotion(ItemStack item) {
        if (item == null) return false;
        Material m = item.getType();
        if (m != Material.POTION && m != Material.SPLASH_POTION && m != Material.LINGERING_POTION) return false;
        if (!(item.getItemMeta() instanceof PotionMeta meta)) return false;
        PotionType type = meta.getBasePotionType();
        if (type == null) return false;
        String name = type.getKey().getKey();
        return name.equals("healing") || name.equals("strong_healing");
    }

    private PotionType donusturInstantDamage(PotionType type) {
        if (type == null) return null;
        String name = type.getKey().getKey();
        return switch (name) {
            case "healing" -> PotionType.HARMING;
            case "strong_healing" -> PotionType.STRONG_HARMING;
            default -> null;
        };
    }

    // =========================================================
    // 2) CAN IKSIRI - custom item (POTION DEGIL), sag tikta aninda tuketilir
    // =========================================================
    private static final String[] CAN_IKSIRI_TIERLERI = {"kucuk", "orta", "buyuk", "mega"};

    public ItemStack canIksiriOlustur(String tier) {
        ItemStack item = new ItemStack(Material.GLASS_BOTTLE);
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(keyCanIksiri, PersistentDataType.STRING, tier);

        String isim;
        int can;
        switch (tier) {
            case "kucuk" -> { isim = "§aKüçük Can İksiri"; can = 4; }
            case "orta"  -> { isim = "§eOrta Can İksiri"; can = 5; }
            case "buyuk" -> { isim = "§6Büyük Can İksiri"; can = 6; }
            case "mega"  -> { isim = "§cMega Can İksiri"; can = 8; }
            default -> { isim = "§7Can İksiri"; can = 4; }
        }
        meta.setDisplayName(isim);
        meta.setLore(List.of(
                "§7Sağ tık: §candında §7+" + can + " can §7verir.",
                "§8Bekleme süresi: 12 saniye"
        ));
        meta.setMaxStackSize(80);
        guvenliItemModelUygula(meta, "item/cursedpowers/can_iksiri_" + tier);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onCanIksiriKullan(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!event.getAction().isRightClick()) return;

        ItemStack item = event.getItem();
        if (item == null) return;
        ItemMeta rawMeta = item.getItemMeta();
        if (rawMeta == null) return;
        if (!rawMeta.getPersistentDataContainer().has(keyCanIksiri, PersistentDataType.STRING)) return;

        event.setCancelled(true); // glass_bottle'in vanilla su doldurma davranisini engelle

        Player p = event.getPlayer();
        UUID uuid = p.getUniqueId();

        long simdi = System.currentTimeMillis();
        Long bitisZamani = canIksiriCooldown.get(uuid);
        if (bitisZamani != null && simdi < bitisZamani) {
            double kalanSaniye = (bitisZamani - simdi) / 1000.0;
            p.sendActionBar("§cCan iksiri bekleme süresi: §e" + String.format("%.1f", kalanSaniye) + "s");
            return;
        }

        String tier = rawMeta.getPersistentDataContainer().get(keyCanIksiri, PersistentDataType.STRING);
        double can = switch (tier) {
            case "kucuk" -> 4;
            case "orta" -> 5;
            case "buyuk" -> 6;
            case "mega" -> 8;
            default -> 4;
        };

        canIksiriCooldown.put(uuid, simdi + CAN_IKSIRI_COOLDOWN_MS);

        double yeniCan = Math.min(p.getHealth() + can, getMaxHealth(p));
        p.setHealth(yeniCan);

        item.setAmount(item.getAmount() - 1);
    }

    private double getMaxHealth(Player p) {
        var attr = p.getAttribute(Attribute.MAX_HEALTH);
        return attr != null ? attr.getValue() : 20.0;
    }

    // =========================================================
    // 3) PARSOMENLER - 3 kategori x 4 tier, 1 saatlik attribute modifier
    // =========================================================
    private static final String[] PARSOMEN_TIERLERI = {
            "saldiri_kucuk", "saldiri_orta", "saldiri_buyuk", "saldiri_mega",
            "defans_kucuk", "defans_orta", "defans_buyuk", "defans_mega",
            "can_kucuk", "can_orta", "can_buyuk", "can_mega"
    };

    public ItemStack parsomenOlustur(String tier) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(keyParsomen, PersistentDataType.STRING, tier);

        String isim = switch (tier) {
            case "saldiri_kucuk" -> "§cKüçük Saldırı Parşömeni";
            case "saldiri_orta" -> "§cOrta Saldırı Parşömeni";
            case "saldiri_buyuk" -> "§4Büyük Saldırı Parşömeni";
            case "saldiri_mega" -> "§4Mega Saldırı Parşömeni";
            case "defans_kucuk" -> "§bKüçük Defans Parşömeni";
            case "defans_orta" -> "§9Orta Defans Parşömeni";
            case "defans_buyuk" -> "§9Büyük Defans Parşömeni";
            case "defans_mega" -> "§1Mega Defans Parşömeni";
            case "can_kucuk" -> "§aKüçük Can Parşömeni";
            case "can_orta" -> "§2Orta Can Parşömeni";
            case "can_buyuk" -> "§6Büyük Can Parşömeni";
            case "can_mega" -> "§4Mega Can Parşömeni";
            default -> "§7Parşömen";
        };
        meta.setDisplayName(isim);
        meta.setLore(List.of(
                "§7Sağ tık: §f1 saat boyunca etki verir.",
                "§8Etki aktifken tekrar kullanılamaz."
        ));
        meta.setMaxStackSize(50);
        guvenliItemModelUygula(meta, "item/cursedpowers/parsomen_" + tier);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onParsomenKullan(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!event.getAction().isRightClick()) return;

        ItemStack item = event.getItem();
        if (item == null) return;
        ItemMeta rawMeta = item.getItemMeta();
        if (rawMeta == null) return;
        if (!rawMeta.getPersistentDataContainer().has(keyParsomen, PersistentDataType.STRING)) return;

        String tier = rawMeta.getPersistentDataContainer().get(keyParsomen, PersistentDataType.STRING);
        Player p = event.getPlayer();
        event.setCancelled(true);

        boolean uygulandi = switch (tier) {
            case "saldiri_kucuk" -> uygula(p, Attribute.ATTACK_DAMAGE, "saldiri", 1.0);
            case "saldiri_orta" -> uygula(p, Attribute.ATTACK_DAMAGE, "saldiri", 2.0);
            case "saldiri_buyuk" -> uygula(p, Attribute.ATTACK_DAMAGE, "saldiri", 3.0);
            case "saldiri_mega" -> uygula(p, Attribute.ATTACK_DAMAGE, "saldiri", 4.0);
            case "defans_kucuk" -> uygula(p, Attribute.ARMOR, "defans", 2.0);
            case "defans_orta" -> uygula(p, Attribute.ARMOR, "defans", 4.0);
            case "defans_buyuk" -> uygula(p, Attribute.ARMOR, "defans", 5.0);
            case "defans_mega" -> uygula(p, Attribute.ARMOR, "defans", 6.0);
            case "can_kucuk" -> uygula(p, Attribute.MAX_HEALTH, "can", 2.0);
            case "can_orta" -> uygula(p, Attribute.MAX_HEALTH, "can", 3.0);
            case "can_buyuk" -> uygula(p, Attribute.MAX_HEALTH, "can", 4.0);
            case "can_mega" -> uygula(p, Attribute.MAX_HEALTH, "can", 6.0);
            default -> false;
        };

        if (!uygulandi) {
            p.sendMessage("§cBu etki zaten aktif, süresi dolmadan tekrar kullanamazsın.");
            return;
        }

        item.setAmount(item.getAmount() - 1);
        p.sendMessage("§aParşömen kullanıldı! Etki 1 saat sürecek.");
    }

    private boolean uygula(Player p, Attribute attribute, String etiket, double miktar) {
        var instance = p.getAttribute(attribute);
        if (instance == null) return false;

        NamespacedKey modKey = new NamespacedKey(this, etiket + "_" + p.getUniqueId());

        boolean zatenVar = instance.getModifiers().stream()
                .anyMatch(m -> m.getKey() != null && m.getKey().equals(modKey));
        if (zatenVar) return false;

        AttributeModifier modifier = new AttributeModifier(modKey, miktar, AttributeModifier.Operation.ADD_NUMBER);
        instance.addModifier(modifier);

        UUID uuid = p.getUniqueId();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            Player oyuncu = Bukkit.getPlayer(uuid);
            if (oyuncu == null) return;
            var inst = oyuncu.getAttribute(attribute);
            if (inst == null) return;
            inst.getModifiers().stream()
                    .filter(m -> m.getKey() != null && m.getKey().equals(modKey))
                    .findFirst()
                    .ifPresent(inst::removeModifier);
            oyuncu.sendMessage("§7" + etiket + " etkisinin süresi doldu.");
        }, SURE_TICKS);

        return true;
    }

    private void guvenliItemModelUygula(ItemMeta meta, String path) {
        try {
            meta.setItemModel(new NamespacedKey("minecraft", path));
        } catch (Throwable t) {
            getLogger().warning("Item model uygulanamadi (" + path + "): " + t);
        }
    }

    // =========================================================
    // KOMUTLAR
    // =========================================================
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        try {
            return onCommandGercek(sender, command, args);
        } catch (Throwable t) {
            getLogger().log(java.util.logging.Level.SEVERE, "Komut hatasi (" + command.getName() + ")", t);
            sender.sendMessage("§cHata: " + t.getClass().getSimpleName() + (t.getMessage() != null ? " - " + t.getMessage() : ""));
            return true;
        }
    }

    private boolean onCommandGercek(CommandSender sender, Command command, String[] args) {
        if (command.getName().equalsIgnoreCase("scall")) {
            return handleScAll(sender, args);
        }

        if (!command.getName().equalsIgnoreCase("guclendiriciver")) return false;
        if (!sender.hasPermission("guclendirici.admin")) {
            sender.sendMessage("§cYetkin yok.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage("§cKullanim: /guclendiriciver <can_iksiri|parsomen> <tier> [oyuncu]");
            return true;
        }

        Player hedef;
        if (args.length >= 3) {
            hedef = Bukkit.getPlayer(args[2]);
            if (hedef == null) {
                sender.sendMessage("§cOyuncu bulunamadi.");
                return true;
            }
        } else if (sender instanceof Player pl) {
            hedef = pl;
        } else {
            sender.sendMessage("§cKonsoldan kullanirken oyuncu belirtmelisin.");
            return true;
        }

        ItemStack verilecek;
        if (args[0].equalsIgnoreCase("can_iksiri")) {
            verilecek = canIksiriOlustur(args[1]);
        } else if (args[0].equalsIgnoreCase("parsomen")) {
            verilecek = parsomenOlustur(args[1]);
        } else {
            sender.sendMessage("§cGecersiz tur.");
            return true;
        }

        hedef.getInventory().addItem(verilecek);
        sender.sendMessage("§aVerildi: " + verilecek.getItemMeta().getDisplayName());
        return true;
    }

    private boolean handleScAll(CommandSender sender, String[] args) {
        if (!sender.hasPermission("guclendirici.admin")) {
            sender.sendMessage("§cYetkin yok.");
            return true;
        }

        Player hedef;
        if (args.length >= 1) {
            hedef = Bukkit.getPlayer(args[0]);
            if (hedef == null) {
                sender.sendMessage("§cOyuncu bulunamadi.");
                return true;
            }
        } else if (sender instanceof Player pl) {
            hedef = pl;
        } else {
            sender.sendMessage("§cKonsoldan kullanirken oyuncu belirtmelisin.");
            return true;
        }

        for (String tier : CAN_IKSIRI_TIERLERI) {
            hedef.getInventory().addItem(canIksiriOlustur(tier));
        }
        for (String tier : PARSOMEN_TIERLERI) {
            hedef.getInventory().addItem(parsomenOlustur(tier));
        }

        hedef.sendMessage("§aTüm Cursed Powers eşyaları envanterine eklendi!");
        if (!sender.equals(hedef)) {
            sender.sendMessage("§a" + hedef.getName() + " oyuncusuna tüm eşyalar verildi.");
        }
        return true;
    }
}
